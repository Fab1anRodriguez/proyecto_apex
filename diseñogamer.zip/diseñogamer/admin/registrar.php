<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar</title>
    <link rel="stylesheet" href="../css/estilo1.css">
</head>
<body class="body">
    <div class="form-container">
        <h2>Registrarse</h2>
        <form method="POST" action="">
            <input type="text" name="nombre" placeholder="Ingrese su nombre" required>
            <input type="email" name="email" placeholder="Ingrese su correo" required>
            <input type="password" name="contraseña" placeholder="Ingrese su contraseña" required>
            <input type="password" name="repetir_contraseña" placeholder="Repetir contraseña" required>
            <button type="submit" name="registrar">Registrarse</button>
            <p><a href="">iniciar sesion </a></p>
        </form>
    </div>
</body>
</html>