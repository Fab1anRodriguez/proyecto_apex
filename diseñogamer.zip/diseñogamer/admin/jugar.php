<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iniciar juego</title>
</head>
<body>
    <img src="../img/juego.jpeg" width="100%"  height="100%">

    <div class="boton">
        <button type="submit" name="jugar">jugar</button>
        <button type="submit" name="cambiar_avatar">cambiar_avatar</button>
        <button type="submit" name="estadisticas">estadisticas</button>
    </div>
    <img src="../img/mundo.jpeg" width="10px" height="1px">
</body>
</html>